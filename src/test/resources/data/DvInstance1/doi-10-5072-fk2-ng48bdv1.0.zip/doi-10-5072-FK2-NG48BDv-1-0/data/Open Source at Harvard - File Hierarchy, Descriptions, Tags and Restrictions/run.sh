#!/bin/sh
# This is the master script.
code/language-count.sh > results/language-count.tsv
